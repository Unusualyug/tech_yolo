# Final research-paper artifacts for `tech_yolo`

Author: **Yug G. Lakhani**  
Department of Computer Engineering, Gyanmanjari Innovative University, Bhavnagar, Gujarat, India  
Email: `yglakhani@gmiu.edu.in` · ORCID: `0009-0004-2930-4953`

This folder contains the final author-version **application/system research paper** prepared from the repository snapshot at commit `6a0405613171a5ed400a7339c3e0a8f6bb94b26d`.

## Final manuscript

- `tech_yolo_final_research_paper.pdf` — formatted single-column manuscript.
- `tech_yolo_final_research_paper.docx` — editable Word manuscript.
- `tech_yolo_final_research_paper.md` — plain-text source with tables and figure links.

## Supporting evidence

- `audit_repository.py` — standard-library static audit; writes `artifacts/repository_audit.json`.
- `artifacts/repository_audit.json` — exact counts, route lists, configuration values, LFS metadata, and source hashes.
- `make_figures.py` — regenerates the two 300-dpi figures.
- `artifacts/fig1_system_architecture.png` and `artifacts/fig2_static_audit_workflow.png` — numbered figures used in the paper.
- `manuscript_content.py` and `build_manuscript.py` — structured manuscript content and the Markdown/PDF/DOCX renderer.
- `requirements-paper.txt` — optional build dependencies; the audit script itself needs only Python 3 and Git.
- `delivery/tech_yolo_final_paper.zip` — archived copy of the final manuscript and supporting evidence.

## Publication notes

The manuscript uses a generic single-column academic format with numeric citations. Before submitting to a specific journal or conference, apply that publication's current official template, citation style, article-type requirements, and page limit. Confirm the funding, competing-interest, and author-contribution declarations against the author's records.

No detection accuracy, mAP, latency, robustness, or user-study result is claimed because the repository contains no dataset, benchmark log, or human-participant evaluation.

## Regeneration

From the repository root:

```bash
python3 paper/audit_repository.py
python3 -m pip install -r paper/requirements-paper.txt
python3 paper/make_figures.py
python3 paper/build_manuscript.py
```
